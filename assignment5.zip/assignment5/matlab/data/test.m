% 
% imgA = imread('pic-1427427217.jpg');
% imgB = imread('pic-1427427219.jpg');
% 
% imgAgray = rgb2gray(imgA);
% imgBgray = rgb2gray(imgB);
% 
% 
% C = corner(imgAgray);
% % subplot(1,2,1);
% imshow(imgAgray);
% hold on
% plot(C(:,1), C(:,2), '*', 'Color', 'c')
% title('Maximum Corners = 200')
% hold off


imgA = iread('pic-1427427217.jpg', 'mono', 'double');
imgB = iread('pic-1427427219.jpg', 'mono', 'double');

% im1 = iread('pic-1427427441.jpg', 'mono', 'double');
featA = isurf(imgA, 'nfeat', 200);
subplot(2,2,1);
idisp(imgA); featA.plot_scale('g');

featB = isurf(imgB, 'nfeat', 200);
subplot(2,2,2);
idisp(imgB); featB.plot_scale('g');
